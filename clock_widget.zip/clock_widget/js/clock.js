(function($, Drupal, drupalSettings) {
    Drupal.behaviors.clockWidget = {
        attach: function (context, settings) {
            var clock_data = drupalSettings.clock_data;
            var path_info_data = drupalSettings.path_info_data;
            console.log(path_info_data);
            var clockElement = document.getElementById('clock-widget');
            setInterval(function () {
                clockElement.textContent = new Date().toLocaleTimeString();
            }, 1000);
        }
    };
})(jQuery, Drupal, drupalSettings);