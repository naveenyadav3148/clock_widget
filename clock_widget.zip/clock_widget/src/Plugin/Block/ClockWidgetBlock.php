<?php

namespace Drupal\clock_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use GuzzleHttp\Client;

/**
 * Provides a 'ClockWidgetBlock' block.
 *
 * @Block(
 *  id = "clock_widget_block",
 *  admin_label = @Translation("Clock widget"),
 * )
 */
class ClockWidgetBlock extends BlockBase implements ContainerFactoryPluginInterface {


/**
   * The request service.
   *
   * @var \Drupal\Core\Http\RequestStack
   */
  protected $requestStack;

  /**
   * HTTP client.
   *
   * @var \GuzzleHttp\Client
   */
  protected $httpClient;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new self(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('request_stack'),
      $container->get('http_client')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    RequestStack $request_stack,
    Client $http_client,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->requestStack = $request_stack;
    $this->httpClient = $http_client;
  }


  /**
   * {@inheritdoc}
   */
  public function build() {

    $build = [];
    $build['clock_widget_block']['#markup'] = '<div id="clock-widget"></div>';

    $current_path = $this->requestStack->getCurrentRequest()->getPathInfo();
    $timezone = $this->requestStack->getCurrentRequest()->query->get('timezone');

    $path_info_data = [
        'current_path' => $current_path,
        'timezone' => $timezone,
    ];

    if (!$timezone) {
      $timezone = 'est';
    }

    // As API was not working, I have hardcoded the data.

    //$clock_api_url = 'http://worldclockapi.com/api/json/'. $timezone .'/now';

    //$clock_data = json_decode($this->httpClient->request('GET', $clock_api_url)->getBody());

    $clock_data = [
        'id' => '12',
        'time' => '5665',
    ];
    
    $build['#attached']['library'][] = 'clock_widget/clock';
    $build['#attached']['drupalSettings']['clock_data'] = $clock_data;
    $build['#attached']['drupalSettings']['path_info_data'] = $path_info_data;

    $build['#cache'] = [
      'contexts' => ['url.query_args'],
      'tags' => ['node_list'],
      'max-age' => 3600,
    ];

    return $build;
  }

}